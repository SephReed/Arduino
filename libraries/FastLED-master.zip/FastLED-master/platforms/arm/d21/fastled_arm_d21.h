#ifndef __INC_FASTLED_ARM_D21_H
#define __INC_FASTLED_ARM_D21_H

#include "fastpin_arm_d21.h"
#include "clockless_arm_d21.h"

#endif
